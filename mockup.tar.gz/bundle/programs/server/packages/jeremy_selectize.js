(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jeremy:selectize'] = {};

})();

//# sourceMappingURL=jeremy_selectize.js.map
