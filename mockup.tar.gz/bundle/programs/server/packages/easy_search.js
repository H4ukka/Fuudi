(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var EasySearch = Package['easysearch:components'].EasySearch;

/* Package-scope variables */
var EasySearch;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['easy:search'] = {
  EasySearch: EasySearch
};

})();

//# sourceMappingURL=easy_search.js.map
