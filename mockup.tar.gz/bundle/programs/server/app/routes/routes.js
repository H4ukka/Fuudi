(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/routes.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.route('/', function () {                                        // 1
    this.render('mockup');                                             // 2
});                                                                    //
                                                                       //
Router.route('/recipes', function () {                                 // 5
    this.render('recipes');                                            // 6
});                                                                    //
                                                                       //
Router.route('/foods/:_category', function () {                        // 9
    var category = this.params._category;                              // 10
                                                                       //
    if (category === "add") {                                          // 12
        this.render('addfood');                                        // 13
    } else {                                                           //
        this.render('foods', {                                         // 15
            data: {                                                    // 16
                fooditem: function () {                                // 17
                    Meteor.subscribe('fuuditest');                     // 18
                    return Foods.find({ kategoria: category }, { sort: { name: 1 } });
                }                                                      //
            }                                                          //
        });                                                            //
    }                                                                  //
});                                                                    //
                                                                       //
Router.route('/categories', function () {                              // 26
    this.render('categories');                                         // 27
});                                                                    //
                                                                       //
Router.route('/allimages', function () {                               // 30
    this.render('allimages');                                          // 31
});                                                                    //
                                                                       //
Router.route('/categories/:_category', function () {                   // 34
    var category = this.params._category;                              // 35
    this.render('subcategories', {                                     // 36
        data: {                                                        // 37
            categoryitem: function () {                                // 38
                var ready = Meteor.subscribe('fuuditest').ready();     // 39
                var allCategories;                                     // 40
                                                                       //
                var allFood = Foods.find({ yläkategoria: category }, {
                    sort: { kategoria: 1 }, fields: { kategoria: true }
                });                                                    //
                                                                       //
                if (ready) {                                           // 46
                    var result = [];                                   // 47
                    allCategories = allFood.map(function (x) {         // 48
                        return x.kategoria;                            // 48
                    });                                                //
                                                                       //
                    var unique_categories = _.uniq(allCategories);     // 50
                                                                       //
                    for (var c in babelHelpers.sanitizeForInObject(unique_categories)) {
                        if (unique_categories[c] !== undefined && unique_categories[c] !== "") {
                            result[result.length] = unique_categories[c];
                        }                                              //
                    }                                                  //
                    return result;                                     // 57
                }                                                      //
            }                                                          //
        }                                                              //
    });                                                                //
});                                                                    //
                                                                       //
Router.route('/food/:_name', function () {                             // 64
    var name = this.params._name;                                      // 65
    this.render('food', {                                              // 66
        data: {                                                        // 67
            fooditem: function () {                                    // 68
                Meteor.subscribe('fuuditest');                         // 69
                return Foods.findOne({ name: name });                  // 70
            }                                                          //
        }                                                              //
    });                                                                //
});                                                                    //
// image: function(){                                                  //
//     var i_id = Foods.findOne({name: name}).image_id;                //
//     return Images.findOne(i_id)                                     //
// }                                                                   //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=routes.js.map
