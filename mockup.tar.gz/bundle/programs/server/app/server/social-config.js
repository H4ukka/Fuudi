(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/social-config.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
ServiceConfiguration.configurations.remove({                           // 1
    service: 'facebook'                                                // 2
});                                                                    //
                                                                       //
ServiceConfiguration.configurations.insert({                           // 5
    service: 'facebook',                                               // 6
    appId: '1242573882423668',                                         // 7
    secret: '582bc5b481cad9d5a524b229e2844008'                         // 8
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=social-config.js.map
