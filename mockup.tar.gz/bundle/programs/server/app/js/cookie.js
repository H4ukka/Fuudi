(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// js/cookie.js                                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
		Template.mockup.onRendered(function () {                             // 2
                                                                       //
				var cookie = Cookies.get('K9yV4xPwGg');                            // 4
                                                                       //
				Meteor.subscribe('getVisitorCount');                               // 6
                                                                       //
				if (cookie) {} else {                                              // 8
                                                                       //
						var user_agent = navigator.userAgent;                            // 12
                                                                       //
						Meteor.call('visitors.insert', user_agent);                      // 14
                                                                       //
						var year = new Date();                                           // 16
						year.setTime(year.getTime() + 365 * 24 * 60 * 60 * 1000);        // 17
						Cookies.set('K9yV4xPwGg', '1', { expires: year, path: '' });     // 18
				}                                                                  //
		});                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=cookie.js.map
