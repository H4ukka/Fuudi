(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// js/fab.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
                                                                       //
	Template.foods.events({                                               // 3
		'click .fab': function (event) {                                     // 4
			Router.go('/foods/add');                                            // 5
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.food.events({                                                // 9
		'click .fab': function (event) {                                     // 10
			Router.go('/foods/add');                                            // 11
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.categories.events({                                          // 15
		'click .fab': function (event) {                                     // 16
			Router.go('/foods/add');                                            // 17
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.subcategories.events({                                       // 21
		'click .fab': function (event) {                                     // 22
			Router.go('/foods/add');                                            // 23
		}                                                                    //
	});                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fab.js.map
