(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// js/mockup.js                                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Foods = new Mongo.Collection("fuuditest");                             // 1
Visitors = new Mongo.Collection("visitors");                           // 2
var imageStore = new FS.Store.GridFS("images");                        // 3
                                                                       //
Images = new FS.Collection("images", {                                 // 5
	stores: [imageStore],                                                 // 6
	filter: {                                                             // 7
		maxSize: 204800, // 200kB                                            // 8
		allow: {                                                             // 9
			contentTypes: ['image/*'],                                          // 10
			extensions: ['png', 'jpg', 'jpeg']                                  // 11
		},                                                                   //
		onInvalid: function (message) {                                      // 13
			if (Meteor.isClient) {                                              // 14
				alert(message);                                                    // 15
			} else {                                                            //
				console.log(message);                                              // 17
			}                                                                   //
		}                                                                    //
	}                                                                     //
});                                                                    //
                                                                       //
PlayersIndex = new EasySearch.Index({                                  // 23
	collection: Foods,                                                    // 24
	fields: ['name', 'kategoria'],                                        // 25
	engine: new EasySearch.MongoDB(),                                     // 26
	defaultSearchOptions: {                                               // 27
		limit: 20                                                            // 28
	}                                                                     //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 32
	'fuuditest.insert': function (name, energy, carbs, sugar, fat, salt, prot, fiber, file_id, category) {
		// Make sure the user is logged in before inserting a task           //
		if (!Meteor.userId()) {                                              // 36
			throw new Meteor.Error('not-authorized');                           // 37
		}                                                                    //
                                                                       //
		Foods.insert({                                                       // 40
			name: name,                                                         // 41
			kategoria: category,                                                // 42
			energia: energy,                                                    // 43
			hiilihydraatti: carbs,                                              // 44
			sokerit: sugar,                                                     // 45
			rasva: fat,                                                         // 46
			suola: salt,                                                        // 47
			proteiini: prot,                                                    // 48
			kuitu: fiber,                                                       // 49
			createdAt: new Date(),                                              // 50
			owner: Meteor.userId(),                                             // 51
			username: Meteor.user().username,                                   // 52
			image_id: file_id                                                   // 53
		});                                                                  //
	},                                                                    //
	'visitors.insert': function (user_agent) {                            // 56
		Visitors.insert({                                                    // 57
			agent: user_agent                                                   // 58
		});                                                                  //
	}                                                                     //
});                                                                    //
                                                                       //
if (Meteor.isClient) {                                                 // 63
                                                                       //
	// function init() {                                                  //
	//     window.addEventListener('scroll', function(e){                 //
	//         var distanceY = window.pageYOffset || document.documentElement.scrollTop,
	//             shrinkOn = 80,                                         //
	//             header = document.querySelector("header");             //
	//         if (distanceY > shrinkOn) {                                //
	//             classie.add(header,"smaller");                         //
	//         } else {                                                   //
	//             if (classie.has(header,"smaller")) {                   //
	//                 classie.remove(header,"smaller");                  //
	//             }                                                      //
	//         }                                                          //
	//     });                                                            //
	// }                                                                  //
	// window.onload = init();                                            //
                                                                       //
	Template.login.events({                                               // 81
		'click #facebook-login': function (event) {                          // 82
			Meteor.loginWithFacebook({}, function (err) {                       // 83
				if (err) {                                                         // 84
					throw new Meteor.Error("Facebook login failed");                  // 85
				}                                                                  //
			});                                                                 //
		},                                                                   //
                                                                       //
		'click #logout': function (event) {                                  // 90
			Meteor.logout(function (err) {                                      // 91
				if (err) {                                                         // 92
					throw new Meteor.Error("Logout failed");                          // 93
				}                                                                  //
			});                                                                 //
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.food.events({                                                // 99
		// Clear search input and results when the user clicks on an itemlink
		'click a.fooditem-link': function (event) {                          // 101
			PlayersIndex.getComponentMethods().search("");                      // 102
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.foodform.events({                                            // 106
		'submit form': function (event, template) {                          // 107
			// Prevent default browser form submit                              //
			event.preventDefault();                                             // 109
                                                                       //
			var file_id;                                                        // 111
                                                                       //
			Images.insert(event.target.image.files[0], function (err, fileObj) {
				if (err) {                                                         // 114
					// handle error                                                   //
					console.log(err);                                                 // 116
				} else {                                                           //
					// handle success depending what you need to do                   //
					file_id = fileObj._id;                                            // 119
                                                                       //
					// Get values from form element                                   //
					var target = event.target;                                        // 122
                                                                       //
					var _name = target.name.value;                                    // 124
					var energy = target.energy.value;                                 // 125
					var carbs = target.carbs.value;                                   // 126
					var sugar = target.sugar.value;                                   // 127
					var fat = target.fat.value;                                       // 128
					var salt = target.salt.value;                                     // 129
					var prot = target.prot.value;                                     // 130
					var fiber = target.fiber.value;                                   // 131
					var category = target.category.value;                             // 132
                                                                       //
					Meteor.call('fuuditest.insert', _name, energy, carbs, sugar, fat, salt, prot, fiber, file_id, category);
                                                                       //
					// Clear form                                                     //
					target.name.value = '';                                           // 138
				}                                                                  //
			});                                                                 //
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.registerHelper('calories', function (kj) {                   // 144
		return (kj / 4.184).toFixed(1);                                      // 145
	});                                                                   //
                                                                       //
	Template.registerHelper('getImageFromId', function (id) {             // 148
		Meteor.subscribe('images');                                          // 149
		var image = Images.findOne({ _id: id });                             // 150
		if (image === undefined) {                                           // 151
			return '/svg/food-icons/cutlery-1.svg';                             // 152
		} else {                                                             //
			return image.url();                                                 // 154
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.foodform.onRendered(function () {                            // 158
                                                                       //
		$('.food-form-body').validate({                                      // 160
			messages: {                                                         // 161
				name: 'Required'                                                   // 162
			}                                                                   //
		});                                                                  //
                                                                       //
		var inputs = document.querySelectorAll('.myFileInput');              // 166
		Array.prototype.forEach.call(inputs, function (input) {              // 167
			var label = input.nextElementSibling,                               // 169
			    labelVal = label.innerHTML;                                     //
                                                                       //
			input.addEventListener('change', function (e) {                     // 172
				var fileName = '';                                                 // 174
				fileName = e.target.value.split('\\').pop();                       // 175
				if (fileName === '') {                                             // 176
					fileName = 'lataa kuva';                                          // 177
				}                                                                  //
				label.querySelector('span').innerHTML = fileName;                  // 179
			});                                                                 //
		});                                                                  //
	});                                                                   //
                                                                       //
	Template.header.onRendered(function () {                              // 184
		// $(window).resize(function() {                                     //
		// 	if($(document).width() > 730) {                                  //
		// 		$('#search-wrap').show();                                       //
		// 	}else{                                                           //
		// 		$('#search-wrap').hide();                                       //
		// 	}                                                                //
		// });                                                               //
                                                                       //
		$('.site-wrap').click(function () {                                  // 193
			$('#nav-trigger').prop('checked', false);                           // 194
		});                                                                  //
	});                                                                   //
                                                                       //
	Template.foodform.helpers({                                           // 198
		distinct_categories: function () {                                   // 199
                                                                       //
			var ready = Meteor.subscribe('fuuditest').ready();                  // 201
			var allCategories;                                                  // 202
                                                                       //
			var allFood = Foods.find({}, {                                      // 204
				sort: { kategoria: 1 }, fields: { kategoria: true }                // 205
			});                                                                 //
                                                                       //
			if (ready) {                                                        // 208
				var result = [];                                                   // 209
				allCategories = allFood.map(function (x) {                         // 210
					return x.kategoria;                                               // 210
				});                                                                //
                                                                       //
				for (var c in babelHelpers.sanitizeForInObject(allCategories)) {   // 212
					if (allCategories[c] !== undefined && allCategories[c] !== "") {  // 213
						result[result.length] = allCategories[c];                        // 214
					}                                                                 //
				}                                                                  //
			}                                                                   //
                                                                       //
			return {                                                            // 219
				categories: _.uniq(result),                                        // 220
				ready: ready                                                       // 221
			};                                                                  //
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.foodsearch.helpers({                                         // 226
		playersIndex: function () {                                          // 227
			return PlayersIndex;                                                //
		}, // instanceof EasySearch.Index                                    //
		inputAttributes: function () {                                       // 228
			return { 'class': 'easy-search-input', 'placeholder': 'Haku...' };  // 229
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.imageView.helpers({                                          // 233
		images: function () {                                                // 234
			Meteor.subscribe('images');                                         // 235
			return Images.find(); // Where Images is an FS.Collection instance  // 236
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.categories.helpers({                                         // 240
		distinct_categories: function () {                                   // 241
                                                                       //
			var ready = Meteor.subscribe('fuuditest').ready();                  // 243
			var allCategories;                                                  // 244
                                                                       //
			var allFood = Foods.find({}, {                                      // 246
				sort: { yläkategoria: 1 }, fields: { yläkategoria: true }          // 247
			});                                                                 //
                                                                       //
			if (ready) {                                                        // 250
				var result = [];                                                   // 251
				allCategories = allFood.map(function (x) {                         // 252
					return x.yläkategoria;                                            // 252
				});                                                                //
                                                                       //
				var unique_categories = _.uniq(allCategories);                     // 254
                                                                       //
				for (var c in babelHelpers.sanitizeForInObject(unique_categories)) {
					if (unique_categories[c] !== undefined && unique_categories[c] !== "") {
						result[result.length] = unique_categories[c];                    // 258
					}                                                                 //
				}                                                                  //
			}                                                                   //
                                                                       //
			return {                                                            // 263
				categories: result,                                                // 264
				ready: ready                                                       // 265
			};                                                                  //
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.header.events({                                              // 270
		'click .searchtoggle': function (event) {                            // 271
			$('#search-wrap').fadeToggle(100);                                  // 272
			//$('.searchtoggle').toggleClass('active');                         //
		}                                                                    //
	});                                                                   //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 278
	Meteor.startup(function () {});                                       // 279
                                                                       //
	Meteor.publish('fuuditest', function () {                             // 283
		return Foods.find({});                                               // 284
	});                                                                   //
                                                                       //
	Meteor.publish('images', function () {                                // 287
		return Images.find({});                                              // 288
	});                                                                   //
                                                                       //
	Meteor.publish('getVisitorCount', function () {                       // 291
		return Visitors.find();                                              // 292
	});                                                                   //
                                                                       //
	Foods.allow({                                                         // 295
		insert: function (userId, doc) {                                     // 296
			// the user must be logged in, and the document must be owned by the user
			return userId && doc.owner === userId;                              // 298
		},                                                                   //
		update: function (userId, doc, fields, modifier) {                   // 300
			// can only change your own documents                               //
			return doc.owner === userId;                                        // 302
		},                                                                   //
		remove: function (userId, doc) {                                     // 304
			// can only remove your own documents                               //
			return doc.owner === userId;                                        // 306
		},                                                                   //
		fetch: ['owner']                                                     // 308
	});                                                                   //
                                                                       //
	Visitors.allow({                                                      // 311
		insert: function (userId, doc) {                                     // 312
			// the user must be logged in, and the document must be owned by the user
			return userId && doc.owner === userId;                              // 314
		}                                                                    //
	});                                                                   //
                                                                       //
	Images.allow({                                                        // 318
		insert: function (userId) {                                          // 319
			return userId;                                                      // 320
		},                                                                   //
		update: function (userId) {                                          // 322
			// can only change your own documents                               //
			return userId;                                                      // 324
		},                                                                   //
		download: function (userId, fileObj) {                               // 326
			return userId;                                                      // 327
		}                                                                    //
	});                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=mockup.js.map
